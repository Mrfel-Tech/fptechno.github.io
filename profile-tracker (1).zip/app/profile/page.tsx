import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardHeader } from "@/components/dashboard-header"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getCurrentUser, getFollowers, getFollowing } from "@/lib/actions"
import { redirect } from "next/navigation"
import Link from "next/link"
import { Settings, UserPlus } from "lucide-react"

export default async function ProfilePage() {
  const currentUser = await getCurrentUser()

  if (!currentUser) {
    redirect("/auth/login")
  }

  // Obter seguidores e seguindo
  const [followersData, followingData] = await Promise.all([getFollowers(), getFollowing()])

  const followers = "followers" in followersData ? followersData.followers : []
  const following = "following" in followingData ? followingData.following : []

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader />
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between space-y-2">
          <h2 className="text-3xl font-bold tracking-tight">Meu Perfil</h2>
          <div className="flex items-center space-x-2">
            <Link href="/settings">
              <Button variant="outline">
                <Settings className="mr-2 h-4 w-4" />
                Configurações
              </Button>
            </Link>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card className="md:col-span-1">
            <CardHeader className="flex flex-col items-center">
              <Avatar className="h-24 w-24">
                <AvatarImage
                  src={currentUser.image || "/placeholder.svg?height=96&width=96"}
                  alt={currentUser.name || "Usuário"}
                />
                <AvatarFallback className="text-2xl">{currentUser.name?.charAt(0) || "U"}</AvatarFallback>
              </Avatar>
              <CardTitle className="mt-4 text-center">{currentUser.name}</CardTitle>
              <CardDescription className="text-center">@{currentUser.username}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-around text-center">
                <div>
                  <p className="text-2xl font-bold">{followers.length}</p>
                  <p className="text-sm text-muted-foreground">Seguidores</p>
                </div>
                <div>
                  <p className="text-2xl font-bold">{following.length}</p>
                  <p className="text-sm text-muted-foreground">Seguindo</p>
                </div>
              </div>

              <div className="pt-4 space-y-2">
                <h3 className="text-sm font-medium">Redes sociais conectadas</h3>
                <div className="flex flex-wrap gap-2">
                  <Button variant="outline" size="sm" className="flex items-center" asChild>
                    <Link href="/connect">
                      <UserPlus className="mr-1 h-4 w-4" />
                      Conectar redes
                    </Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Atividade</CardTitle>
              <CardDescription>Veja sua atividade recente e estatísticas</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="followers">
                <TabsList className="w-full">
                  <TabsTrigger value="followers" className="flex-1">
                    Seguidores
                  </TabsTrigger>
                  <TabsTrigger value="following" className="flex-1">
                    Seguindo
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="followers" className="mt-4 space-y-4">
                  {followers.length > 0 ? (
                    <div className="space-y-4">
                      {followers.slice(0, 5).map((follower: any) => (
                        <div key={follower.id} className="flex items-center space-x-4">
                          <Avatar>
                            <AvatarImage
                              src={follower.image || `/placeholder.svg?height=40&width=40`}
                              alt={follower.name}
                            />
                            <AvatarFallback>{follower.name?.charAt(0) || "U"}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-sm font-medium">{follower.name}</p>
                            <p className="text-sm text-muted-foreground">@{follower.username}</p>
                          </div>
                        </div>
                      ))}
                      {followers.length > 5 && (
                        <Button variant="link" className="w-full">
                          Ver todos os {followers.length} seguidores
                        </Button>
                      )}
                    </div>
                  ) : (
                    <p className="text-center text-muted-foreground">Você ainda não tem seguidores</p>
                  )}
                </TabsContent>
                <TabsContent value="following" className="mt-4 space-y-4">
                  {following.length > 0 ? (
                    <div className="space-y-4">
                      {following.slice(0, 5).map((user: any) => (
                        <div key={user.id} className="flex items-center space-x-4">
                          <Avatar>
                            <AvatarImage src={user.image || `/placeholder.svg?height=40&width=40`} alt={user.name} />
                            <AvatarFallback>{user.name?.charAt(0) || "U"}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-sm font-medium">{user.name}</p>
                            <p className="text-sm text-muted-foreground">@{user.username}</p>
                          </div>
                        </div>
                      ))}
                      {following.length > 5 && (
                        <Button variant="link" className="w-full">
                          Ver todos os {following.length} que você segue
                        </Button>
                      )}
                    </div>
                  ) : (
                    <p className="text-center text-muted-foreground">Você ainda não segue ninguém</p>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

