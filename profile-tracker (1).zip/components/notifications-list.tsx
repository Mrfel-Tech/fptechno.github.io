"use client"

import { useState, useEffect } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { UserCheck, UserMinus, UserPlus, Eye } from "lucide-react"
import { getNotifications, markNotificationAsRead, markAllNotificationsAsRead } from "@/lib/actions"
import { useToast } from "@/hooks/use-toast"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { pusherClient } from "@/lib/pusher"
import { useSession } from "next-auth/react"

export default function NotificationsList() {
  const [notifications, setNotifications] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()
  const { data: session } = useSession()

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const result = await getNotifications()

        if ("error" in result) {
          toast({
            title: "Erro",
            description: result.error,
            variant: "destructive",
          })
          return
        }

        setNotifications(result.notifications || [])
      } catch (error) {
        console.error("Erro ao carregar notificações:", error)
        toast({
          title: "Erro",
          description: "Não foi possível carregar as notificações",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [toast])

  // Configurar Pusher para notificações em tempo real
  useEffect(() => {
    if (!session?.user?.email) return

    const channel = pusherClient.subscribe(`user-${session.user.id}`)

    channel.bind("new-notification", (data: any) => {
      setNotifications((prev) => [
        {
          id: Date.now().toString(),
          type: data.type,
          message: data.message,
          actor: data.actor,
          createdAt: new Date().toISOString(),
          isRead: false,
        },
        ...prev,
      ])

      toast({
        title: "Nova notificação",
        description: data.message,
      })
    })

    return () => {
      pusherClient.unsubscribe(`user-${session.user.id}`)
    }
  }, [session, toast])

  const handleMarkAsRead = async (id: string) => {
    try {
      const result = await markNotificationAsRead(id)

      if ("error" in result) {
        toast({
          title: "Erro",
          description: result.error,
          variant: "destructive",
        })
        return
      }

      // Atualizar estado local
      setNotifications((prev) =>
        prev.map((notification) => (notification.id === id ? { ...notification, isRead: true } : notification)),
      )
    } catch (error) {
      console.error("Erro ao marcar notificação como lida:", error)
      toast({
        title: "Erro",
        description: "Não foi possível marcar a notificação como lida",
        variant: "destructive",
      })
    }
  }

  const handleMarkAllAsRead = async () => {
    try {
      const result = await markAllNotificationsAsRead()

      if ("error" in result) {
        toast({
          title: "Erro",
          description: result.error,
          variant: "destructive",
        })
        return
      }

      // Atualizar estado local
      setNotifications((prev) => prev.map((notification) => ({ ...notification, isRead: true })))

      toast({
        title: "Sucesso",
        description: "Todas as notificações foram marcadas como lidas",
      })
    } catch (error) {
      console.error("Erro ao marcar todas notificações como lidas:", error)
      toast({
        title: "Erro",
        description: "Não foi possível marcar as notificações como lidas",
        variant: "destructive",
      })
    }
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "visit":
        return <Eye className="h-4 w-4 text-blue-500" />
      case "follow":
        return <UserPlus className="h-4 w-4 text-green-500" />
      case "unfollow":
        return <UserMinus className="h-4 w-4 text-red-500" />
      default:
        return <UserCheck className="h-4 w-4" />
    }
  }

  const formatNotificationDate = (date: string) => {
    const notificationDate = new Date(date)
    const now = new Date()
    const diffDays = Math.floor((now.getTime() - notificationDate.getTime()) / (1000 * 60 * 60 * 24))

    if (diffDays === 0) {
      return `Hoje, ${format(notificationDate, "HH:mm")}`
    } else if (diffDays === 1) {
      return `Ontem, ${format(notificationDate, "HH:mm")}`
    } else if (diffDays < 7) {
      return `${diffDays} dias atrás`
    } else {
      return format(notificationDate, "dd 'de' MMMM", { locale: ptBR })
    }
  }

  const unreadCount = notifications.filter((n) => !n.isRead).length

  if (loading) {
    return <div className="flex justify-center p-4">Carregando notificações...</div>
  }

  if (notifications.length === 0) {
    return <div className="text-center p-4">Nenhuma notificação ainda.</div>
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium">{unreadCount} notificações não lidas</p>
        {unreadCount > 0 && (
          <Button variant="outline" size="sm" onClick={handleMarkAllAsRead}>
            Marcar todas como lidas
          </Button>
        )}
      </div>
      <div className="space-y-4">
        {notifications.map((notification) => (
          <div
            key={notification.id}
            className={`flex items-start space-x-4 rounded-lg p-3 ${notification.isRead ? "" : "bg-muted/50"}`}
          >
            <Avatar>
              <AvatarImage
                src={notification.actor?.image || `/placeholder.svg?height=40&width=40`}
                alt={notification.actor?.name || "Usuário"}
              />
              <AvatarFallback>{notification.actor?.name?.charAt(0) || "U"}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center">
                {getNotificationIcon(notification.type)}
                <p className="ml-2 text-sm font-medium">{notification.message}</p>
              </div>
              <p className="text-xs text-muted-foreground">{notification.actor?.username || ""}</p>
              <p className="text-xs text-muted-foreground">{formatNotificationDate(notification.createdAt)}</p>
            </div>
            {!notification.isRead && (
              <Button variant="ghost" size="sm" onClick={() => handleMarkAsRead(notification.id)}>
                Marcar como lida
              </Button>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

