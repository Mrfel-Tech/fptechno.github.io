"use client"

import { useState, useEffect } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { UserCheck, UserPlus } from "lucide-react"
import { getProfileVisitors, followUser, unfollowUser, getFollowing } from "@/lib/actions"
import { useToast } from "@/hooks/use-toast"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

interface ProfileVisitorsListProps {
  limit?: number
}

export default function ProfileVisitorsList({ limit }: ProfileVisitorsListProps) {
  const [visitors, setVisitors] = useState<any[]>([])
  const [following, setFollowing] = useState<Record<string, boolean>>({})
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [visitorsResult, followingResult] = await Promise.all([getProfileVisitors(), getFollowing()])

        if ("error" in visitorsResult) {
          toast({
            title: "Erro",
            description: visitorsResult.error,
            variant: "destructive",
          })
          return
        }

        if ("error" in followingResult) {
          toast({
            title: "Erro",
            description: followingResult.error,
            variant: "destructive",
          })
          return
        }

        setVisitors(visitorsResult.visitors || [])

        // Criar mapa de quem você segue
        const followingMap: Record<string, boolean> = {}
        followingResult.following.forEach((user: any) => {
          followingMap[user.id] = true
        })

        setFollowing(followingMap)
      } catch (error) {
        console.error("Erro ao carregar visitantes:", error)
        toast({
          title: "Erro",
          description: "Não foi possível carregar os visitantes",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [toast])

  const handleFollowToggle = async (userId: string) => {
    try {
      const isFollowing = following[userId]

      const result = isFollowing ? await unfollowUser(userId) : await followUser(userId)

      if ("error" in result) {
        toast({
          title: "Erro",
          description: result.error,
          variant: "destructive",
        })
        return
      }

      // Atualizar estado local
      setFollowing((prev) => ({
        ...prev,
        [userId]: !isFollowing,
      }))

      toast({
        title: isFollowing ? "Deixou de seguir" : "Seguindo",
        description: isFollowing ? "Você deixou de seguir este usuário" : "Você começou a seguir este usuário",
      })
    } catch (error) {
      console.error("Erro ao seguir/deixar de seguir:", error)
      toast({
        title: "Erro",
        description: "Não foi possível realizar esta ação",
        variant: "destructive",
      })
    }
  }

  const formatVisitDate = (date: string) => {
    const visitDate = new Date(date)
    const now = new Date()
    const diffDays = Math.floor((now.getTime() - visitDate.getTime()) / (1000 * 60 * 60 * 24))

    if (diffDays === 0) {
      return `Hoje, ${format(visitDate, "HH:mm")}`
    } else if (diffDays === 1) {
      return `Ontem, ${format(visitDate, "HH:mm")}`
    } else if (diffDays < 7) {
      return `${diffDays} dias atrás`
    } else {
      return format(visitDate, "dd 'de' MMMM", { locale: ptBR })
    }
  }

  const visibleVisitors = limit ? visitors.slice(0, limit) : visitors

  if (loading) {
    return <div className="flex justify-center p-4">Carregando visitantes...</div>
  }

  if (visitors.length === 0) {
    return <div className="text-center p-4">Nenhum visitante registrado ainda.</div>
  }

  return (
    <div className="space-y-4">
      {visibleVisitors.map((visitor) => (
        <div key={visitor.id} className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Avatar>
              <AvatarImage src={visitor.image || `/placeholder.svg?height=40&width=40`} alt={visitor.name} />
              <AvatarFallback>{visitor.name?.charAt(0) || "U"}</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-sm font-medium leading-none">{visitor.name}</p>
              <p className="text-sm text-muted-foreground">{visitor.username}</p>
              <p className="text-xs text-muted-foreground">{formatVisitDate(visitor.visitedAt)}</p>
            </div>
          </div>
          <Button
            variant={following[visitor.id] ? "outline" : "default"}
            size="sm"
            onClick={() => handleFollowToggle(visitor.id)}
          >
            {following[visitor.id] ? (
              <>
                <UserCheck className="mr-2 h-4 w-4" />
                Seguindo
              </>
            ) : (
              <>
                <UserPlus className="mr-2 h-4 w-4" />
                Seguir
              </>
            )}
          </Button>
        </div>
      ))}
      {limit && visitors.length > limit && (
        <Button variant="link" className="w-full" onClick={() => (window.location.href = "/visitors")}>
          Ver todos os {visitors.length} visitantes
        </Button>
      )}
    </div>
  )
}

