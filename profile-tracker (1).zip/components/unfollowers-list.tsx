"use client"

import { useState, useEffect } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { UserPlus } from "lucide-react"
import { getUnfollowers, followUser } from "@/lib/actions"
import { useToast } from "@/hooks/use-toast"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

interface UnfollowersListProps {
  limit?: number
}

export default function UnfollowersList({ limit }: UnfollowersListProps) {
  const [unfollowers, setUnfollowers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const result = await getUnfollowers()

        if ("error" in result) {
          toast({
            title: "Erro",
            description: result.error,
            variant: "destructive",
          })
          return
        }

        setUnfollowers(result.unfollowers || [])
      } catch (error) {
        console.error("Erro ao carregar ex-seguidores:", error)
        toast({
          title: "Erro",
          description: "Não foi possível carregar os ex-seguidores",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [toast])

  const handleFollow = async (userId: string) => {
    try {
      const result = await followUser(userId)

      if ("error" in result) {
        toast({
          title: "Erro",
          description: result.error,
          variant: "destructive",
        })
        return
      }

      // Remover da lista de unfollowers
      setUnfollowers((prev) => prev.filter((user) => user.id !== userId))

      toast({
        title: "Seguindo",
        description: "Você começou a seguir este usuário",
      })
    } catch (error) {
      console.error("Erro ao seguir usuário:", error)
      toast({
        title: "Erro",
        description: "Não foi possível seguir este usuário",
        variant: "destructive",
      })
    }
  }

  const formatUnfollowDate = (date: string) => {
    const unfollowDate = new Date(date)
    const now = new Date()
    const diffDays = Math.floor((now.getTime() - unfollowDate.getTime()) / (1000 * 60 * 60 * 24))

    if (diffDays === 0) {
      return `Hoje, ${format(unfollowDate, "HH:mm")}`
    } else if (diffDays === 1) {
      return `Ontem, ${format(unfollowDate, "HH:mm")}`
    } else if (diffDays < 7) {
      return `${diffDays} dias atrás`
    } else {
      return format(unfollowDate, "dd 'de' MMMM", { locale: ptBR })
    }
  }

  const visibleUnfollowers = limit ? unfollowers.slice(0, limit) : unfollowers

  if (loading) {
    return <div className="flex justify-center p-4">Carregando ex-seguidores...</div>
  }

  if (unfollowers.length === 0) {
    return <div className="text-center p-4">Ninguém deixou de seguir você recentemente.</div>
  }

  return (
    <div className="space-y-4">
      {visibleUnfollowers.map((unfollower) => (
        <div key={unfollower.id} className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Avatar>
              <AvatarImage src={unfollower.image || `/placeholder.svg?height=40&width=40`} alt={unfollower.name} />
              <AvatarFallback>{unfollower.name?.charAt(0) || "U"}</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-sm font-medium leading-none">{unfollower.name}</p>
              <p className="text-sm text-muted-foreground">{unfollower.username}</p>
              <p className="text-xs text-muted-foreground">
                Deixou de seguir: {formatUnfollowDate(unfollower.unfollowedAt)}
              </p>
            </div>
          </div>
          <Button variant="default" size="sm" onClick={() => handleFollow(unfollower.id)}>
            <UserPlus className="mr-2 h-4 w-4" />
            Seguir
          </Button>
        </div>
      ))}
      {limit && unfollowers.length > limit && (
        <Button variant="link" className="w-full" onClick={() => (window.location.href = "/unfollowers")}>
          Ver todos os {unfollowers.length} que deixaram de seguir
        </Button>
      )}
    </div>
  )
}

