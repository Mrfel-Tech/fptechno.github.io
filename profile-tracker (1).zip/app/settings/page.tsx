"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DashboardHeader } from "@/components/dashboard-header"
import { useState, useEffect } from "react"
import { useToast } from "@/hooks/use-toast"
import { updateUserProfile, updatePassword } from "@/lib/actions"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"

export default function SettingsPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [user, setUser] = useState<any>(null)
  const { toast } = useToast()
  const { data: session, update } = useSession()
  const router = useRouter()

  useEffect(() => {
    if (session?.user) {
      setUser({
        name: session.user.name || "",
        email: session.user.email || "",
        username: session.user.username || "",
        bio: session.user.bio || "",
      })
    }
  }, [session])

  const handleProfileSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const formData = new FormData(e.currentTarget)
      const result = await updateUserProfile(formData)

      if ("error" in result) {
        toast({
          title: "Erro",
          description: result.error,
          variant: "destructive",
        })
        return
      }

      // Atualizar sessão
      await update({
        ...session,
        user: {
          ...session?.user,
          name: formData.get("name") as string,
          username: formData.get("username") as string,
        },
      })

      toast({
        title: "Sucesso",
        description: "Perfil atualizado com sucesso",
      })
    } catch (error) {
      console.error("UPDATE_PROFILE_ERROR", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao atualizar o perfil",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handlePasswordSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const formData = new FormData(e.currentTarget)
      const result = await updatePassword(formData)

      if ("error" in result) {
        toast({
          title: "Erro",
          description: result.error,
          variant: "destructive",
        })
        return
      }

      toast({
        title: "Sucesso",
        description: "Senha atualizada com sucesso",
      })

      // Limpar campos
      e.currentTarget.reset()
    } catch (error) {
      console.error("UPDATE_PASSWORD_ERROR", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao atualizar a senha",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (!user) {
    return (
      <div className="flex min-h-screen flex-col">
        <DashboardHeader />
        <div className="flex-1 flex items-center justify-center">
          <p>Carregando configurações...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader />
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between space-y-2">
          <h2 className="text-3xl font-bold tracking-tight">Configurações</h2>
        </div>
        <Tabs defaultValue="profile" className="space-y-4">
          <TabsList>
            <TabsTrigger value="profile">Perfil</TabsTrigger>
            <TabsTrigger value="notifications">Notificações</TabsTrigger>
            <TabsTrigger value="account">Conta</TabsTrigger>
          </TabsList>
          <TabsContent value="profile" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Informações do Perfil</CardTitle>
                <CardDescription>Atualize suas informações pessoais</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <form onSubmit={handleProfileSubmit} className="space-y-4">
                  <div className="grid gap-2">
                    <Label htmlFor="name">Nome</Label>
                    <Input id="name" name="name" defaultValue={user.name} disabled={isLoading} />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="username">Nome de usuário</Label>
                    <Input id="username" name="username" defaultValue={user.username} disabled={isLoading} />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" name="email" defaultValue={user.email} disabled={true} />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="bio">Biografia</Label>
                    <Input id="bio" name="bio" defaultValue={user.bio} disabled={isLoading} />
                  </div>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading ? "Salvando..." : "Salvar Alterações"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="notifications" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Preferências de Notificação</CardTitle>
                <CardDescription>Configure como e quando deseja receber notificações</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between space-x-2">
                  <Label htmlFor="notify-visits">Notificar sobre visitas ao perfil</Label>
                  <Switch id="notify-visits" defaultChecked />
                </div>
                <div className="flex items-center justify-between space-x-2">
                  <Label htmlFor="notify-unfollows">Notificar quando alguém deixar de seguir</Label>
                  <Switch id="notify-unfollows" defaultChecked />
                </div>
                <div className="flex items-center justify-between space-x-2">
                  <Label htmlFor="notify-follows">Notificar sobre novos seguidores</Label>
                  <Switch id="notify-follows" defaultChecked />
                </div>
                <div className="flex items-center justify-between space-x-2">
                  <Label htmlFor="email-notifications">Receber notificações por email</Label>
                  <Switch id="email-notifications" />
                </div>
                <Button type="button">Salvar Preferências</Button>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="account" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Segurança da Conta</CardTitle>
                <CardDescription>Atualize sua senha e configurações de segurança</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <form onSubmit={handlePasswordSubmit} className="space-y-4">
                  <div className="grid gap-2">
                    <Label htmlFor="current-password">Senha atual</Label>
                    <Input id="current-password" name="current-password" type="password" disabled={isLoading} />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="new-password">Nova senha</Label>
                    <Input id="new-password" name="new-password" type="password" disabled={isLoading} />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="confirm-password">Confirmar nova senha</Label>
                    <Input id="confirm-password" name="confirm-password" type="password" disabled={isLoading} />
                  </div>
                  <div className="flex items-center justify-between space-x-2">
                    <Label htmlFor="two-factor">Autenticação de dois fatores</Label>
                    <Switch id="two-factor" />
                  </div>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading ? "Atualizando..." : "Atualizar Senha"}
                  </Button>
                </form>
              </CardContent>
            </Card>
            <Card className="border-red-200">
              <CardHeader>
                <CardTitle className="text-red-500">Zona de Perigo</CardTitle>
                <CardDescription>Ações irreversíveis para sua conta</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="destructive">Excluir Conta</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

