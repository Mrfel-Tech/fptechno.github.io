import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Bell, UserMinus, UserPlus, Users } from "lucide-react"
import ProfileVisitorsList from "@/components/profile-visitors-list"
import UnfollowersList from "@/components/unfollowers-list"
import NotificationsList from "@/components/notifications-list"
import { DashboardHeader } from "@/components/dashboard-header"
import { getProfileVisitors, getFollowers, getUnfollowers, getFollowing } from "@/lib/actions"
import { getCurrentUser } from "@/lib/actions"
import { redirect } from "next/navigation"
import Link from "next/link"

export default async function Home() {
  const currentUser = await getCurrentUser()

  if (!currentUser) {
    redirect("/auth/login")
  }

  // Obter dados para o dashboard
  const [visitorsData, followersData, unfollowersData, followingData] = await Promise.all([
    getProfileVisitors(),
    getFollowers(),
    getUnfollowers(),
    getFollowing(),
  ])

  const visitors = "visitors" in visitorsData ? visitorsData.visitors : []
  const followers = "followers" in followersData ? followersData.followers : []
  const unfollowers = "unfollowers" in unfollowersData ? unfollowersData.unfollowers : []
  const following = "following" in followingData ? followingData.following : []

  // Calcular estatísticas
  const recentVisitorsCount = visitors.length
  const unfollowersCount = unfollowers.length
  const newFollowersCount = followers.length

  return (
    <main className="flex min-h-screen flex-col">
      <DashboardHeader />
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between space-y-2">
          <h2 className="text-3xl font-bold tracking-tight">Painel de Controle</h2>
          <div className="flex items-center space-x-2">
            <Link href="/notifications">
              <Button>
                <Bell className="mr-2 h-4 w-4" />
                Notificações
              </Button>
            </Link>
          </div>
        </div>
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Visão Geral</TabsTrigger>
            <TabsTrigger value="visitors">Visitantes</TabsTrigger>
            <TabsTrigger value="unfollowers">Deixaram de Seguir</TabsTrigger>
            <TabsTrigger value="notifications">Notificações</TabsTrigger>
          </TabsList>
          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Visitantes Recentes</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{recentVisitorsCount}</div>
                  <p className="text-xs text-muted-foreground">Total de visitantes registrados</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Deixaram de Seguir</CardTitle>
                  <UserMinus className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{unfollowersCount}</div>
                  <p className="text-xs text-muted-foreground">Total de pessoas que deixaram de seguir</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Seguidores</CardTitle>
                  <UserPlus className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{newFollowersCount}</div>
                  <p className="text-xs text-muted-foreground">Total de seguidores</p>
                </CardContent>
              </Card>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <Card className="col-span-1">
                <CardHeader>
                  <CardTitle>Visitantes Recentes</CardTitle>
                  <CardDescription>Pessoas que visitaram seu perfil recentemente</CardDescription>
                </CardHeader>
                <CardContent>
                  <ProfileVisitorsList limit={5} />
                </CardContent>
              </Card>
              <Card className="col-span-1">
                <CardHeader>
                  <CardTitle>Deixaram de Seguir</CardTitle>
                  <CardDescription>Pessoas que deixaram de seguir você recentemente</CardDescription>
                </CardHeader>
                <CardContent>
                  <UnfollowersList limit={5} />
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="visitors" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Todos os Visitantes</CardTitle>
                <CardDescription>Lista completa de pessoas que visitaram seu perfil</CardDescription>
              </CardHeader>
              <CardContent>
                <ProfileVisitorsList />
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="unfollowers" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Todos que Deixaram de Seguir</CardTitle>
                <CardDescription>Lista completa de pessoas que deixaram de seguir você</CardDescription>
              </CardHeader>
              <CardContent>
                <UnfollowersList />
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="notifications" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Notificações</CardTitle>
                <CardDescription>Histórico de notificações sobre seu perfil</CardDescription>
              </CardHeader>
              <CardContent>
                <NotificationsList />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}

