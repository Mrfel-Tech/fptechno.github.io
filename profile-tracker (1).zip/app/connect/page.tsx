"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardHeader } from "@/components/dashboard-header"
import { Instagram, Twitter, Facebook } from "lucide-react"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

export default function ConnectPage() {
  const [isConnecting, setIsConnecting] = useState<string | null>(null)
  const { toast } = useToast()
  const router = useRouter()

  const handleConnect = async (provider: string) => {
    setIsConnecting(provider)

    try {
      // Simulação de conexão com rede social
      await new Promise((resolve) => setTimeout(resolve, 2000))

      toast({
        title: "Conectado com sucesso",
        description: `Sua conta ${provider} foi conectada.`,
      })

      router.push("/")
    } catch (error) {
      console.error(`${provider.toUpperCase()}_CONNECT_ERROR`, error)
      toast({
        title: "Erro",
        description: `Não foi possível conectar com ${provider}`,
        variant: "destructive",
      })
    } finally {
      setIsConnecting(null)
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader />
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between space-y-2">
          <h2 className="text-3xl font-bold tracking-tight">Conectar Redes Sociais</h2>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Instagram className="mr-2 h-5 w-5 text-pink-500" />
                Instagram
              </CardTitle>
              <CardDescription>Conecte sua conta do Instagram para rastrear seguidores e visitantes</CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                onClick={() => handleConnect("instagram")}
                disabled={isConnecting === "instagram"}
              >
                {isConnecting === "instagram" ? "Conectando..." : "Conectar Instagram"}
              </Button>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Twitter className="mr-2 h-5 w-5 text-blue-400" />
                Twitter
              </CardTitle>
              <CardDescription>Conecte sua conta do Twitter para rastrear seguidores e visitantes</CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                className="w-full bg-blue-400 hover:bg-blue-500"
                onClick={() => handleConnect("twitter")}
                disabled={isConnecting === "twitter"}
              >
                {isConnecting === "twitter" ? "Conectando..." : "Conectar Twitter"}
              </Button>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Facebook className="mr-2 h-5 w-5 text-blue-600" />
                Facebook
              </CardTitle>
              <CardDescription>Conecte sua conta do Facebook para rastrear seguidores e visitantes</CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                className="w-full bg-blue-600 hover:bg-blue-700"
                onClick={() => handleConnect("facebook")}
                disabled={isConnecting === "facebook"}
              >
                {isConnecting === "facebook" ? "Conectando..." : "Conectar Facebook"}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

