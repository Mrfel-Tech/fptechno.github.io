"use client"

import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Bell, Menu, Settings, User, UserCheck, LogOut } from "lucide-react"
import { useEffect, useState } from "react"
import { getNotifications } from "@/lib/actions"
import { signOut, useSession } from "next-auth/react"
import { pusherClient } from "@/lib/pusher"
import { usePathname } from "next/navigation"

export function DashboardHeader() {
  const [unreadCount, setUnreadCount] = useState(0)
  const [notifications, setNotifications] = useState<any[]>([])
  const { data: session } = useSession()
  const pathname = usePathname()

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const result = await getNotifications()

        if ("error" in result) {
          console.error(result.error)
          return
        }

        setNotifications(result.notifications.slice(0, 5))
        setUnreadCount(result.notifications.filter((n: any) => !n.isRead).length)
      } catch (error) {
        console.error("Erro ao carregar notificações:", error)
      }
    }

    fetchNotifications()
  }, [pathname])

  // Configurar Pusher para notificações em tempo real
  useEffect(() => {
    if (!session?.user?.email) return

    const channel = pusherClient.subscribe(`user-${session.user.id}`)

    channel.bind("new-notification", (data: any) => {
      setUnreadCount((prev) => prev + 1)
      setNotifications((prev) => [
        {
          id: Date.now().toString(),
          type: data.type,
          message: data.message,
          actor: data.actor,
          createdAt: new Date().toISOString(),
          isRead: false,
        },
        ...prev.slice(0, 4),
      ])
    })

    return () => {
      pusherClient.unsubscribe(`user-${session.user.id}`)
    }
  }, [session])

  return (
    <header className="sticky top-0 z-40 border-b bg-background">
      <div className="container flex h-16 items-center justify-between py-4">
        <div className="flex items-center gap-2 md:gap-4">
          <Button variant="outline" size="icon" className="md:hidden">
            <Menu className="h-5 w-5" />
            <span className="sr-only">Toggle Menu</span>
          </Button>
          <Link href="/" className="flex items-center space-x-2">
            <UserCheck className="h-6 w-6" />
            <span className="hidden font-bold sm:inline-block">ProfileTracker</span>
          </Link>
        </div>
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                {unreadCount > 0 && (
                  <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground">
                    {unreadCount > 9 ? "9+" : unreadCount}
                  </span>
                )}
                <span className="sr-only">Notificações</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Notificações</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {notifications.length > 0 ? (
                <>
                  {notifications.map((notification) => (
                    <DropdownMenuItem key={notification.id}>{notification.message}</DropdownMenuItem>
                  ))}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/notifications" className="w-full text-center cursor-pointer">
                      Ver todas
                    </Link>
                  </DropdownMenuItem>
                </>
              ) : (
                <DropdownMenuItem>Nenhuma notificação</DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="relative">
                <Avatar className="h-8 w-8">
                  <AvatarImage
                    src={session?.user?.image || "/placeholder.svg?height=32&width=32"}
                    alt={session?.user?.name || "Usuário"}
                  />
                  <AvatarFallback>{session?.user?.name?.charAt(0) || "U"}</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Minha Conta</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/profile">
                  <User className="mr-2 h-4 w-4" />
                  <span>Perfil</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/settings">
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Configurações</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => signOut({ callbackUrl: "/auth/login" })}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Sair</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}

