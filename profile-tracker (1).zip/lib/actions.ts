"use server"

import { revalidatePath } from "next/cache"
import { prisma } from "./prisma"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import bcrypt from "bcryptjs"
import { pusherServer } from "./pusher"

// Função para obter o usuário atual
export async function getCurrentUser() {
  const session = await getServerSession(authOptions)

  if (!session?.user?.email) {
    return null
  }

  const currentUser = await prisma.user.findUnique({
    where: {
      email: session.user.email as string,
    },
  })

  if (!currentUser) {
    return null
  }

  return {
    ...currentUser,
    hashedPassword: undefined,
  }
}

// Registro de usuário
export async function registerUser(formData: FormData) {
  try {
    const name = formData.get("name") as string
    const email = formData.get("email") as string
    const username = formData.get("username") as string
    const password = formData.get("password") as string
    const confirmPassword = formData.get("confirm-password") as string

    if (!name || !email || !username || !password) {
      return { error: "Todos os campos são obrigatórios" }
    }

    if (password !== confirmPassword) {
      return { error: "As senhas não coincidem" }
    }

    const existingUser = await prisma.user.findFirst({
      where: {
        OR: [{ email }, { username }],
      },
    })

    if (existingUser) {
      return { error: "Email ou nome de usuário já está em uso" }
    }

    const hashedPassword = await bcrypt.hash(password, 12)

    const user = await prisma.user.create({
      data: {
        name,
        email,
        username,
        hashedPassword,
      },
    })

    return { success: "Conta criada com sucesso" }
  } catch (error) {
    console.error("REGISTRATION_ERROR", error)
    return { error: "Erro ao registrar usuário" }
  }
}

// Obter seguidores
export async function getFollowers() {
  try {
    const currentUser = await getCurrentUser()

    if (!currentUser) {
      return { error: "Não autorizado" }
    }

    const followers = await prisma.follow.findMany({
      where: {
        followingId: currentUser.id,
        unfollowedAt: null,
      },
      include: {
        follower: {
          select: {
            id: true,
            name: true,
            username: true,
            image: true,
          },
        },
      },
      orderBy: {
        createdAt: "desc",
      },
    })

    return { followers: followers.map((follow) => follow.follower) }
  } catch (error) {
    console.error("GET_FOLLOWERS_ERROR", error)
    return { error: "Erro ao obter seguidores" }
  }
}

// Obter quem você segue
export async function getFollowing() {
  try {
    const currentUser = await getCurrentUser()

    if (!currentUser) {
      return { error: "Não autorizado" }
    }

    const following = await prisma.follow.findMany({
      where: {
        followerId: currentUser.id,
        unfollowedAt: null,
      },
      include: {
        following: {
          select: {
            id: true,
            name: true,
            username: true,
            image: true,
          },
        },
      },
      orderBy: {
        createdAt: "desc",
      },
    })

    return { following: following.map((follow) => follow.following) }
  } catch (error) {
    console.error("GET_FOLLOWING_ERROR", error)
    return { error: "Erro ao obter quem você segue" }
  }
}

// Obter quem deixou de seguir você
export async function getUnfollowers() {
  try {
    const currentUser = await getCurrentUser()

    if (!currentUser) {
      return { error: "Não autorizado" }
    }

    const unfollowers = await prisma.follow.findMany({
      where: {
        followingId: currentUser.id,
        unfollowedAt: {
          not: null,
        },
      },
      include: {
        follower: {
          select: {
            id: true,
            name: true,
            username: true,
            image: true,
          },
        },
      },
      orderBy: {
        unfollowedAt: "desc",
      },
    })

    return {
      unfollowers: unfollowers.map((follow) => ({
        ...follow.follower,
        unfollowedAt: follow.unfollowedAt,
      })),
    }
  } catch (error) {
    console.error("GET_UNFOLLOWERS_ERROR", error)
    return { error: "Erro ao obter ex-seguidores" }
  }
}

// Obter visitantes do perfil
export async function getProfileVisitors() {
  try {
    const currentUser = await getCurrentUser()

    if (!currentUser) {
      return { error: "Não autorizado" }
    }

    const visitors = await prisma.profileVisit.findMany({
      where: {
        profileId: currentUser.id,
      },
      include: {
        visitor: {
          select: {
            id: true,
            name: true,
            username: true,
            image: true,
          },
        },
      },
      orderBy: {
        visitedAt: "desc",
      },
    })

    return {
      visitors: visitors.map((visit) => ({
        ...visit.visitor,
        visitedAt: visit.visitedAt,
        isRead: visit.isRead,
      })),
    }
  } catch (error) {
    console.error("GET_VISITORS_ERROR", error)
    return { error: "Erro ao obter visitantes" }
  }
}

// Registrar visita ao perfil
export async function registerProfileVisit(profileId: string) {
  try {
    const currentUser = await getCurrentUser()

    if (!currentUser) {
      return { error: "Não autorizado" }
    }

    if (currentUser.id === profileId) {
      return { error: "Não é possível registrar visita ao próprio perfil" }
    }

    const visit = await prisma.profileVisit.create({
      data: {
        visitorId: currentUser.id,
        profileId,
      },
    })

    // Criar notificação para o dono do perfil
    await prisma.notification.create({
      data: {
        userId: profileId,
        type: "visit",
        actorId: currentUser.id,
        message: `${currentUser.name} visitou seu perfil`,
      },
    })

    // Enviar notificação em tempo real
    await pusherServer.trigger(`user-${profileId}`, "new-notification", {
      type: "visit",
      actor: {
        id: currentUser.id,
        name: currentUser.name,
        username: currentUser.username,
        image: currentUser.image,
      },
      message: `${currentUser.name} visitou seu perfil`,
    })

    return { success: true }
  } catch (error) {
    console.error("REGISTER_VISIT_ERROR", error)
    return { error: "Erro ao registrar visita" }
  }
}

// Seguir usuário
export async function followUser(userId: string) {
  try {
    const currentUser = await getCurrentUser()

    if (!currentUser) {
      return { error: "Não autorizado" }
    }

    if (currentUser.id === userId) {
      return { error: "Não é possível seguir a si mesmo" }
    }

    // Verificar se já segue
    const existingFollow = await prisma.follow.findUnique({
      where: {
        followerId_followingId: {
          followerId: currentUser.id,
          followingId: userId,
        },
      },
    })

    if (existingFollow && !existingFollow.unfollowedAt) {
      return { error: "Você já segue este usuário" }
    }

    // Se já seguiu antes, atualiza o registro
    if (existingFollow) {
      await prisma.follow.update({
        where: {
          id: existingFollow.id,
        },
        data: {
          unfollowedAt: null,
        },
      })
    } else {
      // Senão, cria um novo registro
      await prisma.follow.create({
        data: {
          followerId: currentUser.id,
          followingId: userId,
        },
      })
    }

    // Criar notificação
    await prisma.notification.create({
      data: {
        userId,
        type: "follow",
        actorId: currentUser.id,
        message: `${currentUser.name} começou a seguir você`,
      },
    })

    // Enviar notificação em tempo real
    await pusherServer.trigger(`user-${userId}`, "new-notification", {
      type: "follow",
      actor: {
        id: currentUser.id,
        name: currentUser.name,
        username: currentUser.username,
        image: currentUser.image,
      },
      message: `${currentUser.name} começou a seguir você`,
    })

    revalidatePath("/")
    return { success: true }
  } catch (error) {
    console.error("FOLLOW_USER_ERROR", error)
    return { error: "Erro ao seguir usuário" }
  }
}

// Deixar de seguir usuário
export async function unfollowUser(userId: string) {
  try {
    const currentUser = await getCurrentUser()

    if (!currentUser) {
      return { error: "Não autorizado" }
    }

    const follow = await prisma.follow.findUnique({
      where: {
        followerId_followingId: {
          followerId: currentUser.id,
          followingId: userId,
        },
      },
    })

    if (!follow || follow.unfollowedAt) {
      return { error: "Você não segue este usuário" }
    }

    await prisma.follow.update({
      where: {
        id: follow.id,
      },
      data: {
        unfollowedAt: new Date(),
      },
    })

    // Criar notificação
    await prisma.notification.create({
      data: {
        userId,
        type: "unfollow",
        actorId: currentUser.id,
        message: `${currentUser.name} deixou de seguir você`,
      },
    })

    revalidatePath("/")
    return { success: true }
  } catch (error) {
    console.error("UNFOLLOW_USER_ERROR", error)
    return { error: "Erro ao deixar de seguir usuário" }
  }
}

// Obter notificações
export async function getNotifications() {
  try {
    const currentUser = await getCurrentUser()

    if (!currentUser) {
      return { error: "Não autorizado" }
    }

    const notifications = await prisma.notification.findMany({
      where: {
        userId: currentUser.id,
      },
      orderBy: {
        createdAt: "desc",
      },
      take: 50,
    })

    // Obter informações dos atores das notificações
    const actorIds = notifications.filter((n) => n.actorId).map((n) => n.actorId as string)

    const actors = await prisma.user.findMany({
      where: {
        id: {
          in: actorIds,
        },
      },
      select: {
        id: true,
        name: true,
        username: true,
        image: true,
      },
    })

    const actorsMap = actors.reduce(
      (acc, actor) => {
        acc[actor.id] = actor
        return acc
      },
      {} as Record<string, any>,
    )

    return {
      notifications: notifications.map((notification) => ({
        ...notification,
        actor: notification.actorId ? actorsMap[notification.actorId] : null,
      })),
    }
  } catch (error) {
    console.error("GET_NOTIFICATIONS_ERROR", error)
    return { error: "Erro ao obter notificações" }
  }
}

// Marcar notificação como lida
export async function markNotificationAsRead(notificationId: string) {
  try {
    const currentUser = await getCurrentUser()

    if (!currentUser) {
      return { error: "Não autorizado" }
    }

    await prisma.notification.update({
      where: {
        id: notificationId,
        userId: currentUser.id,
      },
      data: {
        isRead: true,
      },
    })

    revalidatePath("/")
    return { success: true }
  } catch (error) {
    console.error("MARK_NOTIFICATION_ERROR", error)
    return { error: "Erro ao marcar notificação como lida" }
  }
}

// Marcar todas notificações como lidas
export async function markAllNotificationsAsRead() {
  try {
    const currentUser = await getCurrentUser()

    if (!currentUser) {
      return { error: "Não autorizado" }
    }

    await prisma.notification.updateMany({
      where: {
        userId: currentUser.id,
        isRead: false,
      },
      data: {
        isRead: true,
      },
    })

    revalidatePath("/")
    return { success: true }
  } catch (error) {
    console.error("MARK_ALL_NOTIFICATIONS_ERROR", error)
    return { error: "Erro ao marcar notificações como lidas" }
  }
}

// Marcar visita como lida
export async function markVisitAsRead(visitId: string) {
  try {
    const currentUser = await getCurrentUser()

    if (!currentUser) {
      return { error: "Não autorizado" }
    }

    await prisma.profileVisit.update({
      where: {
        id: visitId,
        profileId: currentUser.id,
      },
      data: {
        isRead: true,
      },
    })

    revalidatePath("/")
    return { success: true }
  } catch (error) {
    console.error("MARK_VISIT_ERROR", error)
    return { error: "Erro ao marcar visita como lida" }
  }
}

// Atualizar perfil do usuário
export async function updateUserProfile(formData: FormData) {
  try {
    const currentUser = await getCurrentUser()

    if (!currentUser) {
      return { error: "Não autorizado" }
    }

    const name = formData.get("name") as string
    const username = formData.get("username") as string
    const bio = formData.get("bio") as string

    if (!name || !username) {
      return { error: "Nome e nome de usuário são obrigatórios" }
    }

    // Verificar se o username já está em uso
    if (username !== currentUser.username) {
      const existingUser = await prisma.user.findUnique({
        where: {
          username,
        },
      })

      if (existingUser) {
        return { error: "Nome de usuário já está em uso" }
      }
    }

    await prisma.user.update({
      where: {
        id: currentUser.id,
      },
      data: {
        name,
        username,
        // Adicionar bio quando adicionarmos ao schema
      },
    })

    revalidatePath("/settings")
    return { success: "Perfil atualizado com sucesso" }
  } catch (error) {
    console.error("UPDATE_PROFILE_ERROR", error)
    return { error: "Erro ao atualizar perfil" }
  }
}

// Atualizar senha
export async function updatePassword(formData: FormData) {
  try {
    const currentUser = await getCurrentUser()

    if (!currentUser) {
      return { error: "Não autorizado" }
    }

    const currentPassword = formData.get("current-password") as string
    const newPassword = formData.get("new-password") as string
    const confirmPassword = formData.get("confirm-password") as string

    if (!currentPassword || !newPassword || !confirmPassword) {
      return { error: "Todos os campos são obrigatórios" }
    }

    if (newPassword !== confirmPassword) {
      return { error: "As senhas não coincidem" }
    }

    // Verificar senha atual
    const user = await prisma.user.findUnique({
      where: {
        id: currentUser.id,
      },
    })

    if (!user || !user.hashedPassword) {
      return { error: "Usuário não encontrado" }
    }

    const isCorrectPassword = await bcrypt.compare(currentPassword, user.hashedPassword)

    if (!isCorrectPassword) {
      return { error: "Senha atual incorreta" }
    }

    // Atualizar senha
    const hashedPassword = await bcrypt.hash(newPassword, 12)

    await prisma.user.update({
      where: {
        id: currentUser.id,
      },
      data: {
        hashedPassword,
      },
    })

    return { success: "Senha atualizada com sucesso" }
  } catch (error) {
    console.error("UPDATE_PASSWORD_ERROR", error)
    return { error: "Erro ao atualizar senha" }
  }
}

